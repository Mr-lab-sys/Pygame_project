import pygame
import sys
import random
import json
import os

# Параметры окна
WIDTH = 800
HEIGHT = 600
FPS = 60

# Цвета
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
BLUE = (0, 0, 255)
GREEN = (0, 255, 0)

# Размеры платформы и блока
PADDLE_WIDTH = 100
PADDLE_HEIGHT = 10
BLOCK_WIDTH = 75
BLOCK_HEIGHT = 30

# Названия скинов мячей
ball_skins = ['data/default_ball.png', 'data/gold_ball.png', 'data/column_ball.png', 'data/volleyball.png']

# Пороговые значения для разблокировки скинов
skin_unlock_thresholds = [0, 50, 100, 200]  # Например, на 500, 1000 и 2000 очков разблокируются скины

SAVE_FILE = "game_progress.json"


def load_progress():
    """Загрузка прогресса из файла"""
    if os.path.exists(SAVE_FILE):
        with open(SAVE_FILE, "r") as file:
            return json.load(file)
    return {"selected_ball": 0, "high_score": 0, "total_score": 0,
            "unlocked_skins": [0]}  # Первоначально разблокирован первый скин


def save_progress(selected_ball, high_score, total_score, unlocked_skins):
    """Сохранение прогресса в файл"""
    with open(SAVE_FILE, "w") as file:
        json.dump({"selected_ball": selected_ball, "high_score": high_score, "total_score": total_score,
                   "unlocked_skins": unlocked_skins}, file)


class Paddle:
    def __init__(self):
        self.rect = pygame.Rect((WIDTH - PADDLE_WIDTH) // 2, HEIGHT - 30, PADDLE_WIDTH, PADDLE_HEIGHT)
        self.speed = 7

    def move(self, keys):
        if keys[pygame.K_LEFT] and self.rect.left > 0:
            self.rect.x -= self.speed
        if keys[pygame.K_RIGHT] and self.rect.right < WIDTH:
            self.rect.x += self.speed

    def draw(self):
        pygame.draw.rect(screen, BLUE, self.rect)


class Ball:
    def __init__(self, skin_path, speed):
        self.original_image = pygame.image.load(skin_path)
        self.image = pygame.transform.scale(self.original_image, (
            self.original_image.get_width() // 30, self.original_image.get_height() // 30))
        self.rect = self.image.get_rect(center=(WIDTH // 2, HEIGHT // 2))
        self.dx = random.choice([-speed, speed])
        self.dy = -speed

    def move(self):
        self.rect.x += self.dx
        self.rect.y += self.dy
        if self.rect.left <= 0 or self.rect.right >= WIDTH:
            self.dx = -self.dx
        if self.rect.top <= 0:
            self.dy = -self.dy

    def draw(self):
        screen.blit(self.image, self.rect)


class Block:
    def __init__(self, x, y):
        self.rect = pygame.Rect(x, y, BLOCK_WIDTH, BLOCK_HEIGHT)

    def draw(self):
        pygame.draw.rect(screen, GREEN, self.rect)


def create_blocks(rows, cols):
    blocks = []
    for row in range(rows):
        for col in range(cols):
            x = col * (BLOCK_WIDTH + 5) + 5
            y = row * (BLOCK_HEIGHT + 5) + 5
            blocks.append(Block(x, y))
    return blocks


def main_menu():
    selected_option = 0
    options = ["Лёгкий", "Средний", "Сложный", "Магазин", "Выход"]
    while True:
        screen.fill(BLACK)
        font = pygame.font.Font(None, 74)
        title_text = font.render('Выберите уровень', True, WHITE)

        for i, option in enumerate(options):
            color = RED if i == selected_option else WHITE
            option_text = font.render(option, True, color)
            screen.blit(option_text, (WIDTH // 2 - option_text.get_width() // 2, HEIGHT // 2 + i * 50))

        screen.blit(title_text, (WIDTH // 2 - title_text.get_width() // 2, HEIGHT // 2 - 100))

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_UP:
                    selected_option = (selected_option - 1) % len(options)
                elif event.key == pygame.K_DOWN:
                    selected_option = (selected_option + 1) % len(options)
                elif event.key == pygame.K_RETURN:
                    return selected_option

        pygame.display.flip()


def shop_menu(progress):
    selected_ball = progress["selected_ball"]
    unlocked_skins = progress["unlocked_skins"]
    total_score = progress["total_score"]  # Получаем общий счёт

    skin_spacing = 150  # Расстояние между скинами

    while True:
        screen.fill(BLACK)

        font = pygame.font.Font(None, 37)
        title_text = font.render('Магазин', True, WHITE)
        score_text = font.render(f'Общий счёт: {total_score}', True, WHITE)  # Показываем общий счёт

        # Отрисовка скинов и информации о разблокировке
        for i, ball_skin in enumerate(ball_skins):
            ball_image = pygame.image.load(ball_skin)
            ball_image = pygame.transform.scale(ball_image, (50, 50))
            x = (WIDTH // 2 - ((len(ball_skins) * skin_spacing) // 2)) + (i * skin_spacing)
            screen.blit(ball_image, (x, HEIGHT // 2))

            if i == selected_ball:
                pygame.draw.rect(screen, RED, (x, HEIGHT // 2, 50, 50), 5)

            # Если скин заблокирован, показываем, сколько очков нужно для разблокировки
            if i not in unlocked_skins:
                unlock_cost = skin_unlock_thresholds[i]  # Берём порог разблокировки
                locked_text = font.render(f'{unlock_cost} очков', True, RED)
                screen.blit(locked_text, (x, HEIGHT // 2 + 50))

        # Отрисовка заголовка и счёта
        screen.blit(title_text, (WIDTH // 2 - title_text.get_width() // 2, HEIGHT // 2 - 150))
        screen.blit(score_text, (WIDTH // 2 - score_text.get_width() // 2, HEIGHT // 2 - 100))

        # Обработка событий
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT:
                    selected_ball = (selected_ball - 1) % len(ball_skins)
                elif event.key == pygame.K_RIGHT:
                    selected_ball = (selected_ball + 1) % len(ball_skins)
                elif event.key == pygame.K_RETURN:
                    if selected_ball in unlocked_skins:
                        return selected_ball  # Если скин разблокирован, выбираем его
                    else:
                        progress["unlocked_skins"].append(selected_ball)
                        save_progress(progress["selected_ball"], progress["high_score"], progress["total_score"],
                                      progress["unlocked_skins"])
                        return selected_ball

        pygame.display.flip()


def game_over_screen(score, progress):
    if score > progress["high_score"]:
        progress["high_score"] = score
    progress["total_score"] += score
    save_progress(progress["selected_ball"], progress["high_score"], progress["total_score"],
                  progress["unlocked_skins"])

    while True:
        screen.fill(BLACK)
        font = pygame.font.Font(None, 50)
        title_text = font.render('Игра окончена', True, WHITE)
        score_text = font.render(f'Ваш счёт: {score}', True, WHITE)
        instruction_text = font.render('Нажмите Enter для возврата в меню', True, WHITE)

        screen.blit(title_text, (WIDTH // 2 - title_text.get_width() // 2, HEIGHT // 2 - 100))
        screen.blit(score_text, (WIDTH // 2 - score_text.get_width() // 2, HEIGHT // 2))
        screen.blit(instruction_text, (WIDTH // 2 - instruction_text.get_width() // 2, HEIGHT // 2 + 100))

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RETURN:
                    return

        pygame.display.flip()


def main(selected_ball_index, progress, difficulty):
    difficulties = {
        0: (3, 7),  # Лёгкий (медленный мяч, больше блоков)
        1: (4, 5),  # Средний (обычный мяч, стандартное число блоков)
        2: (6, 3)  # Сложный (быстрый мяч, меньше блоков)
    }
    ball_speed, block_rows = difficulties[difficulty]

    paddle = Paddle()
    ball = Ball(ball_skins[selected_ball_index], ball_speed)
    blocks = create_blocks(block_rows, WIDTH // (BLOCK_WIDTH + 5))
    score = 0
    running = True
    paused = False

    while running:
        screen.fill(BLACK)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    paused = not paused

        if paused:
            font = pygame.font.Font(None, 50)
            pause_text = font.render("Нажмите ПРОБЕЛ для продолжения.", True, WHITE)
            screen.blit(pause_text, (WIDTH // 2 - pause_text.get_width() // 2, HEIGHT // 2))
            pygame.display.flip()
            clock.tick(FPS)
            continue

        keys = pygame.key.get_pressed()
        paddle.move(keys)
        ball.move()

        if ball.rect.colliderect(paddle.rect):
            ball.dy = -ball.dy

        for block in blocks[:]:
            if ball.rect.colliderect(block.rect):
                ball.dy = -ball.dy
                blocks.remove(block)
                score += 1
            if len(blocks) == 0:
                game_over_screen(score, progress)
                return

        if ball.rect.top > HEIGHT:
            game_over_screen(score, progress)
            return

        paddle.draw()
        ball.draw()
        for block in blocks:
            block.draw()

        font = pygame.font.Font(None, 36)
        score_text = font.render(f'Счёт: {score}', True, WHITE)
        screen.blit(score_text, (10, 10))

        # Разблокируем скины по мере набора очков
        for i, threshold in enumerate(skin_unlock_thresholds):
            if score >= threshold and i not in progress["unlocked_skins"]:
                progress["unlocked_skins"].append(i)

        pygame.display.flip()
        clock.tick(FPS)


pygame.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Арканоид")
clock = pygame.time.Clock()
pygame.mixer.music.load("data/top_music.mp3")
pygame.mixer.music.play(loops=-1)

progress = load_progress()

selected_ball_index = progress["selected_ball"]
while True:
    selected_option = main_menu()
    if selected_option in [0, 1, 2]:
        main(selected_ball_index, progress, selected_option)
    elif selected_option == 3:
        selected_ball_index = shop_menu(progress)
    elif selected_option == 4:
        pygame.quit()
        sys.exit()
