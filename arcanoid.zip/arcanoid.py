import pygame
import sys
import random

# Параметры окна
WIDTH = 800
HEIGHT = 600
FPS = 60

# Цвета
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
BLUE = (0, 0, 255)
GREEN = (0, 255, 0)

# Размеры платформы и блока
PADDLE_WIDTH = 100
PADDLE_HEIGHT = 10
BLOCK_WIDTH = 75
BLOCK_HEIGHT = 30

# Названия скинов мячей
ball_skins = ['data/default_ball.png', 'data/gold_ball.png', 'data/column_ball.png', 'data/volleyball.png']


# Класс платформы
class Paddle:
    def __init__(self):
        self.rect = pygame.Rect((WIDTH - PADDLE_WIDTH) // 2, HEIGHT - 30, PADDLE_WIDTH, PADDLE_HEIGHT)
        self.speed = 7  # Скорость движения

    def move(self, keys):
        if keys[pygame.K_LEFT] and self.rect.left > 0:
            self.rect.x -= self.speed
        if keys[pygame.K_RIGHT] and self.rect.right < WIDTH:
            self.rect.x += self.speed

    def draw(self):
        pygame.draw.rect(screen, BLUE, self.rect)


# Класс мяча
class Ball:
    def __init__(self, skin_path):
        self.original_image = pygame.image.load(skin_path)
        self.image = pygame.transform.scale(self.original_image, (
            self.original_image.get_width() // 30, self.original_image.get_height() // 30))
        self.rect = self.image.get_rect(center=(WIDTH // 2, HEIGHT // 2))
        self.dx = random.choice([-4, 4])
        self.dy = -4

    def move(self):
        self.rect.x += self.dx
        self.rect.y += self.dy
        # Отскок от стен
        if self.rect.left <= 0 or self.rect.right >= WIDTH:
            self.dx = -self.dx
        if self.rect.top <= 0:
            self.dy = -self.dy

    def draw(self):
        screen.blit(self.image, self.rect)


# Класс блоков
class Block:
    def __init__(self, x, y):
        self.rect = pygame.Rect(x, y, BLOCK_WIDTH, BLOCK_HEIGHT)

    def draw(self):
        pygame.draw.rect(screen, GREEN, self.rect)


# Функция создания блоков
def create_blocks():
    blocks = []
    for row in range(5):
        for col in range(WIDTH // (BLOCK_WIDTH + 5)):
            x = col * (BLOCK_WIDTH + 5) + 5
            y = row * (BLOCK_HEIGHT + 5) + 5
            blocks.append(Block(x, y))
    return blocks


# Функция главного меню
def main_menu():
    selected_option = 0  # 0 - "Начать игру", 1 - "Магазин", 2 - "Выход"
    options = ["Начать игру", "Магазин", "Выход"]
    while True:
        screen.fill(BLACK)
        font = pygame.font.Font(None, 74)
        title_text = font.render('Главное меню', True, WHITE)

        # Отображаем текстовые опции
        for i, option in enumerate(options):
            color = RED if i == selected_option else WHITE  # Выделение выбранной опции
            option_text = font.render(option, True, color)
            screen.blit(option_text, (WIDTH // 2 - option_text.get_width() // 2, HEIGHT // 2 + i * 50))

        screen.blit(title_text, (WIDTH // 2 - title_text.get_width() // 2, HEIGHT // 2 - 100))

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_UP:
                    selected_option = (selected_option - 1) % len(options)  # Переключение вверх
                elif event.key == pygame.K_DOWN:
                    selected_option = (selected_option + 1) % len(options)  # Переключение вниз
                elif event.key == pygame.K_RETURN:  # Нажатие "Enter"
                    return selected_option  # Возвращаем номер выбранной опции

        pygame.display.flip()


# Функция магазина
def shop_menu():
    selected_ball = 0  # Индекс выбранного мяча
    while True:
        screen.fill(BLACK)
        font = pygame.font.Font(None, 74)
        title_text = font.render('Магазин', True, WHITE)

        # Отображаем спрайты мячей
        for i, ball_skin in enumerate(ball_skins):
            ball_image = pygame.image.load(ball_skin)
            ball_image = pygame.transform.scale(ball_image, (50, 50))  # Установите размер по вашему усмотрению
            x = (WIDTH // 2 - ((len(ball_skins) * 55) // 2)) + (i * 55)
            screen.blit(ball_image, (x, HEIGHT // 2))

            # Отображение выделения
            if i == selected_ball:
                pygame.draw.rect(screen, RED, (x, HEIGHT // 2, 50, 50), 5)  # Красная рамка

        screen.blit(title_text, (WIDTH // 2 - title_text.get_width() // 2, HEIGHT // 2 - 100))

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT:
                    selected_ball = (selected_ball - 1) % len(ball_skins)  # Переключение влево
                elif event.key == pygame.K_RIGHT:
                    selected_ball = (selected_ball + 1) % len(ball_skins)  # Переключение вправо
                elif event.key == pygame.K_RETURN:  # Нажатие "Enter"
                    return selected_ball  # Возвращаемся в главное меню

        pygame.display.flip()


# Функция экрана окончания игры
def game_over_screen(score):
    while True:
        screen.fill(BLACK)
        font = pygame.font.Font(None, 50)
        title_text = font.render('Игра окончена', True, WHITE)
        score_text = font.render(f'Ваш счёт: {score}', True, WHITE)
        instruction_text = font.render('Нажмите Enter для возврата в меню', True, WHITE)

        screen.blit(title_text, (WIDTH // 2 - title_text.get_width() // 2, HEIGHT // 2 - 100))
        screen.blit(score_text, (WIDTH // 2 - score_text.get_width() // 2, HEIGHT // 2))
        screen.blit(instruction_text, (WIDTH // 2 - instruction_text.get_width() // 2, HEIGHT // 2 + 100))

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RETURN:
                    return  # Возврат в главное меню

        pygame.display.flip()


# Основной цикл игры
def main(selected_ball_index):
    paddle = Paddle()
    ball = Ball(ball_skins[selected_ball_index])  # Используем выбранный скин мяча
    blocks = create_blocks()
    score = 0  # Счет
    running = True

    while running:
        screen.fill(BLACK)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

        keys = pygame.key.get_pressed()
        paddle.move(keys)
        ball.move()

        # Проверка столкновений мяча с платформой
        if ball.rect.colliderect(paddle.rect):
            ball.dy = -ball.dy

        # Проверка столкновений мяча с блоками
        for block in blocks[:]:
            if ball.rect.colliderect(block.rect):
                ball.dy = -ball.dy
                blocks.remove(block)
                score += 1  # Увеличиваем счет

        # Проверка, упал ли мяч ниже платформы
        if ball.rect.top > HEIGHT:
            game_over_screen(score)  # Переход к экрану окончания игры
            return

        # Отрисовка объектов
        paddle.draw()
        ball.draw()
        for block in blocks:
            block.draw()

        # Отображение счёта на экране
        font = pygame.font.Font(None, 36)
        score_text = font.render(f'Счёт: {score}', True, WHITE)
        screen.blit(score_text, (10, 10))

        pygame.display.flip()
        clock.tick(FPS)


# Инициализация Pygame и запуск игры
pygame.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Арканоид")
clock = pygame.time.Clock()

if __name__ == "__main__":
    selected_ball_index = 0  # Изначально выбран первый мяч
    while True:
        selected_option = main_menu()  # Вызов главного меню перед началом игры
        if selected_option == 0:
            main(selected_ball_index)  # Начинаем игру
        elif selected_option == 1:
            selected_ball_index = shop_menu()  # Переход в магазин
        elif selected_option == 2:
            pygame.quit()
            sys.exit()  # Выход
